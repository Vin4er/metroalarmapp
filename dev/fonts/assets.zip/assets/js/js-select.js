(function(){
	localStorage.setItem('activeline', false)
	localStorage.setItem('activename', false)

	

$(function(){


		$(".o-clocker-settings").removeClass('hidden')
		$(".o-clocker-loading").addClass('animated fadeOut')
		setTimeout(function(){
			$(".o-clocker-loading").addClass('hidden')
		}, 500 )

	window.typeahead_one_Init();
	window.arrayCustomize();

	$('.likerstile').change(function(){

		window.metro_item = window[$(this).val()]

		localStorage.setItem('metroname', $(this).val())
		console.log(	localStorage.getItem('metroname'))

		$('.o-clocker-settings-selects-item.to').removeClass('fadeInLeft');
		$('.o-clocker-settings-selects-item.to').addClass('animated fadeOut');
		$('.o-clocker-settings-timer').removeClass('hidden fadeInLeft').addClass('animated fadeOut');
		$('.typehead').val('');
		$(".o-clocker-sleep").trigger('timer:end');

		window.stepController(1);

		window.arrayCustomize();
	})
});
// Выставляем порядковые
window.arrayCustomize = function(){
	var metroLength = window.metro_item.length;
	for(var lineItem = 0; lineItem < metroLength; lineItem++ ){
		var goToLineLength = window.metro_item[lineItem].length;
		for(var item = 0; item < goToLineLength ; item++){
			window.metro_item[lineItem][item].place = item
			window.metro_item[lineItem][item].line = window.metro_item[lineItem][item].line-1
		}
	}
}

_Typeahead = _Handlebars = {};

window.tphd = [$('.o-clocker-settings-selects-item.from .typehead'), $('.o-clocker-settings-selects-item.to .typehead')];

// Переключает шаги внизу
window.stepController = function (step) {
	$('.o-clocker-settings-steps-items .o-clocker-settings-steps-item').removeClass('active')
	$('.o-clocker-settings-steps-items .o-clocker-settings-steps-item').slice(0, step).addClass('active')
	$('.o-clocker-settings-steps-line-item').css({width: step==3?"100%":step==2?"50%":0})

	if(step != 3){
		$(".o-clocker-sleep").trigger('timer:end')
	}
}

// поиск по массивам
var substringMatcher = function(strs) {
	return function findMatches(q, cb) {

	    var  matches = [];

		var substrRegex = new RegExp(q, 'i');

		var metroLength = window.metro_item.length;

		for(var lineItem = 0; lineItem < metroLength; lineItem++ ){

			var goToLine = window.metro_item[lineItem]

			var goToLineLength = goToLine.length;
			for(var item = 0; item < goToLineLength ; item++){

				if (substrRegex.test( goToLine[item].name  )) {
					
					if( localStorage.getItem('activeline') != "undefined" && localStorage.getItem('activeline')!="false" ){
						// отсекаем эту же станцию и выводим запросы по данной линии
						if( goToLine[item].line == localStorage.getItem('activeline') &&  goToLine[item].name != localStorage.getItem('activename')) {
							
							matches.push(goToLine[item]);
						}

					}else{

						matches.push(goToLine[item]);

					}

				}

			}
		}
		cb(matches);
	};
};


_Typeahead.modelSettings = function(){
	return {
		source: substringMatcher(),
		display: 'name',
		templates: {
			empty: '<div class="empty-message">Нет такой станции</div>',
			suggestion: _Handlebars.compile()
		}
	}
}
_Handlebars.compile = function(){
	return Handlebars.compile('<div style="color: {{color}}" ><strong>{{name}}</strong></div>');
}


// инициализация и ипереиниицализация второй строки поиска
window.typeahead_two_Init = function(){

	window.tphd[1].val('').typeahead('destroy');
	// инит тайпхеда
	window.tphd[1].typeahead({}, _Typeahead.modelSettings() )

	window.tphd[1].on('typeahead:select', function(ev, suggestion) {
		typeahead_two_Changed(suggestion)
	}).on('input blur change', function(e) {
		// слуашем все события
		if(this.value=="") typeahead_two_Changed();
	});


};

	
window.typeahead_two_Changed = function(suggestion){
	if( suggestion ) {
		window.stepController(3)
		$('.o-clocker-settings-timer').removeClass('hidden fadeOut').addClass('animated fadeInLeft');

		_Typeahead['TO'] = suggestion;

		$(".o-clocker-sleep").trigger('timer:start', _Typeahead )

	}else{
		window.stepController(2)
		$('.o-clocker-settings-timer').removeClass('hidden fadeInLeft').addClass('animated fadeOut');
	}

}

window.typeahead_one_Changed = function(suggestion){
	var obj = suggestion
	console.log(suggestion)
	// Пишем в сторедж активные
	if( suggestion  ) {

		localStorage.setItem('activeline', suggestion.line)
		localStorage.setItem('activename', suggestion.name)

		$('.o-clocker-settings-selects-item.to').removeClass('hidden fadeOut').addClass('animated fadeInLeft')
		typeahead_two_Init();
		window.stepController(2)
		_Typeahead['FROM'] = suggestion;

	}else{

		$('.o-clocker-settings-selects-item.to').removeClass('fadeInLeft');

		$('.o-clocker-settings-selects-item.to').addClass('animated fadeOut');
		$('.o-clocker-settings-timer').removeClass('hidden fadeInLeft').addClass('animated fadeOut');

		window.tphd[1].val('').typeahead('destroy');
		window.stepController(1)

		localStorage.setItem('activeline', false)
		localStorage.setItem('activename', false)
	}

};


window.typeahead_one_Init = function(){

	// инит тайпхеда
	window.tphd[0].typeahead({}, _Typeahead.modelSettings());

	window.tphd[0].on('typeahead:select', function(ev, suggestion) {
		typeahead_one_Changed(suggestion)
	}).on('typeahead:open', function(ev, suggestion) {
		// когда открываем - очищаем сторедж и активный
		localStorage.setItem('activeline', false);
		localStorage.setItem('activename', false);
	}).on('input blur  change', function(e) {
		// слуашем все события
		if(this.value=="") typeahead_one_Changed();
	});

}



})();

// data-place='"+j+"' data-color='"+M.color+"' data-newline='"+M.newline+"' data-time='"+M.time+"' data-line='"+LINE+"'