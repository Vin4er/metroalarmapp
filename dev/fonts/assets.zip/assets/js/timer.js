




_TIMER  = {
	start: false,
	timer: ''
}

$(function(){






	window.audio = new Audio(); // Создаём новый элемент Audio
	window.audio.src = 'Oxygen.ogg'; // Указываем путь к звуку "клика"
	window.audio.autoplay = false;

	$('body').on('click', '.o-clocker-settings-timer-button a', function(e){
		e.preventDefault();

		if( _TIMER.start ){

			$('.o-clocker-settings').removeClass('hidden').addClass('animated fadeOutUp')
			$('.o-clocker-sleep').removeClass('hidden').addClass('animated fadeInUp')
			

		}else{
			return false;
		}
	})

	// сброс
	.on('click', '.resetMetro', function(e){
		e.preventDefault();

			$('.o-clocker-settings-selects-item.to').removeClass('fadeInLeft');
			$('.o-clocker-settings-selects-item.to').addClass('animated fadeOut');
			$('.o-clocker-settings-timer').removeClass('hidden fadeInLeft').addClass('animated fadeOut');
			$('.typehead').val('');
			$(".o-clocker-sleep").trigger('timer:end');
			window.stepController(1)
	});

	// Таймер начнаем
	$(".o-clocker-sleep").on('timer:start', function(event, data){
		console.log('start', data)
		_TIMER  = {
			start: true,
			timer: setTimer(data)
		}

	})


	// Таймер остановливаем
	.on('timer:end', function(event, data){
		console.log('end')

		if( _TIMER.start ){
			$('.o-clocker-settings').removeClass('hidden animated fadeOutUp').addClass('animated fadeInUp')
			$('.o-clocker-sleep').removeClass('hidden animated fadeInUp').addClass('hidden')
		}

		clearInterval(_TIMER.timer);

		_TIMER  = {
			start: false,
			timer: ''
		}


		if(data){

			$('.o-clocker-settings-selects-item.to').removeClass('fadeInLeft');
			$('.o-clocker-settings-selects-item.to').addClass('animated fadeOut');
			$('.o-clocker-settings-timer').removeClass('hidden fadeInLeft').addClass('animated fadeOut');
			$('.typehead').val('');

			window.audio.play();
		}



	})
});







var DELTA  =  2; // 1 минут в минус
//склонение окончаний
function declension(num, expressions) {
    var result;
    count = num % 100;
    if (count >= 5 && count <= 20) {
        result = expressions['2'];
    } else {
        count = count % 10;
        if (count == 1) {
            result = expressions['0'];
        } else if (count >= 2 && count <= 4) {
            result = expressions['1'];
        } else {
            result = expressions['2'];
        }
    }
    return result;
}


//  t = минуты
var setDate = function(t){
    t = t*60*1000; //мллескекунды
    return  new Date(new Date().getTime() + t);
};


window.setTimer = function(data){

	window.calculate(data);
	var ___TIME =  window.SET_GLOBAL_MINUTES(false);

 	$('.bigtimer, .minutes').text(window.SET_GLOBAL_MINUTES(false));

	return setInterval(function(){

		___TIME--;
		// если ноль
		if(___TIME == 0){
			window.stepController(1)
			$(".o-clocker-sleep").trigger('timer:end', {finish: true})
		}
	 	$('.bigtimer, .minutes').text(___TIME);
	 	$('.wrap-time b, .o-clocker-sleep-bigtimer .cell div').html(declension(___TIME, ['минуту', 'минуты', 'минут']))

	}, 1000*60);
};


window.SET_GLOBAL_MINUTES = function(__true, ___ ){
    if( __true == true ){
       window.GLOBAL_MINUTES  = ( parseInt(___) > 3 ? parseInt(___) - DELTA : parseInt(___) - 1 ) 
    }
    return  window.GLOBAL_MINUTES;
};

window.calculate = function(data){
	console.log(data)
	var path = {
	    from: {
	        line:    data['FROM'].line,
	        time:    data['FROM'].time,
	        place:   data['FROM'].place,
	        circle:  data['FROM'].circle?data['FROM'].circle:false,
	    },
	    to: {
	        line:    data['TO'].line,
	        time:    data['TO'].time,
	        place:   data['TO'].place,
	        circle:  data['TO'].circle?data['TO'].circle:false,
	    }
	},
	a1 = path.from.place, a2 = path.to.place, t = 0, _t=0, h=0, m=0, a_bool = a1<a2;
	a2=a_bool?a1:a2;
	a1=a_bool?path.to.place:a1;
	var rv = 0;
	if(a2!=a1){
	    if(path.to.line == path.from.line){
	        // проверяем все варианты путей
	        var _t = 0;

	        console.log(path.from.line, path.to.line, window.metro_item)
	        
	        for(var i=a2; i<a1; i++ ){
	            _t += parseInt(window.metro_item[path.from.line][i].time);
	        }

	        var t = 0;

	        if(path.to.circle ){

	            var i = a2, length = window.metro_item[path.from.line].length
	                do{
	                i--;
	                if(i == -1){
	                    i = length-1 
	                }
	                t += parseInt(window.metro_item[path.from.line][i].time);
	            }while( i != a1 );
	        }
	      
	        if( t == 0) {
	            window.SET_GLOBAL_MINUTES(true, _t);
	        }else{
	            if( _t == 0) {
	                window.SET_GLOBAL_MINUTES(true, t);
	            }else{
	                window.SET_GLOBAL_MINUTES(true, t>_t?_t:t );
	            }
	        }
			$(".o-clocker-sleep-metro-from").text(data['FROM'].name)
			$(".o-clocker-sleep-metro-to").text(data['TO'].name)
  		 	$('.bigtimer, .minutes').text(window.SET_GLOBAL_MINUTES(false));
  		 	$('.wrap-time b, .o-clocker-sleep-bigtimer .cell div').html(declension(window.SET_GLOBAL_MINUTES(false), ['минуту', 'минуты', 'минут']))

	        // window.alert ('Я вас разбужу через ' + window.SET_GLOBAL_MINUTES(false) + " " +  declension(window.SET_GLOBAL_MINUTES(false), ['минуту', 'минуты', 'минут'])  )

	    // }
	    }
    }
};