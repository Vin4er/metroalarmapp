$(function(){
	window.masks().tabs().facny().hshchange();
})
window.see_hash = function(){
	if ( location.hash == '' ||  location.hash == "#js-tab-1") {
		$('[href="#js-tab-1"]').click()
	}else if(location.hash== "#js-tab-2"){
		$('[href="#js-tab-2"]').click()
	}
}
window.hshchange = function(){
	window.see_hash();
	$(window).on('hashchange', window.see_hash)
	return this
}
window.facny = function(){
	$('.fancyapps').fancybox()
	return this
}
window.selectopen = function(){
	$('.select').click(function(){
		$(this).find('select').trigger('click')
	})
	return this
}
window.masks = function(){
	$('.mask_date').mask('99.99.9999');
	$('.num_order').mask('9999.99-99/2099');
	return this
}
window.tabs = function(){
	$( 'a.js-tabs-header-item' ).click(window.tabchange)
	return this
}
window.tabchange = function(e){
	$('.js-tabs-header-item, .js-tabs-body-item').removeClass('active')
	$(e.currentTarget).add(e.currentTarget.hash).addClass('active')
	return this
};